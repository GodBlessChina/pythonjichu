# O(1)

def f1(n):
    print("hello")  # 1
    print("hello")  # 1
    print("hello")

# O(n)
def f2(n):
    for i in range(n):
        print("hello")
        print("hello")
# n=1 t=2   n=2 t=4  n=1000 t=2000    y=x

# O(n^2)
def f3(n):
    for i in range(n):
        for j in range(n):
            print("hello")
# O(n^3)
def f4(n):
    for i in range(n):
        for j in range(n):
            for k in range(n):
                print("hello")

# O(2^n)
def  ff(n):
    if n==1 or n==2:
        return 1
    return ff(n-1)+ff(n-2)

f2(7)