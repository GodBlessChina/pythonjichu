# 递归 ： 函数自己调用自己。无条件的递归是死循环
# RecursionError 递归错误 maximum recursion depth exceeded while calling a Python object

# 1 1  2  3  5  8  13  21  34 55 89 144 。。。。

def  f(n):
    if n==1 or n==2:
        return 1
    return f(n-1)+f(n-2)

fblq = f(100)
print(fblq)

