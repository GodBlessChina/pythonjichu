# 递归的缺点：算法复杂度 O(2^n) ，n太大时，函数图像高度超过了O(n^3)
# 下面的代码的复杂度为 O(n^3)
"""
def f4(n):
    for i in range(n):
        for j in range(n):
            for k in range(n):
                print("hello")
f4(10)
"""

# for循环求斐波拉契数列


def f(n):
    people1 = 1
    people2 = 1
    yellow_people = 1
    for month in range(1, n+1):
        if month == 1 or month == 2:
            yellow_people = 1
            print(f"第{month}月,兔子数量是{yellow_people}")
        # 如果代码走到这里，说明if不成立，也就不是1月和2月
        people1 = people2
        people2 = yellow_people
        yellow_people = people1 + people2
        print(f"第{month}月,兔子数量是{yellow_people}")

f(100)