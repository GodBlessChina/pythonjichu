def wrapper_param(param):
    def wrapper_func(func):
        def inner(func_param1,func_param2):
            print(f'装饰器的参数{param}')
            print('执行前')
            res = func(func_param1, func_param2)
            print('执行后')
            return res
        return inner
    return wrapper_func

@wrapper_param('hello')
def f(x,y):
    print("f执行")
    return x+y

res = f(1,2)
print(res)