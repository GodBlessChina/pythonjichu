# 在不修改f的情况下，给f函数计时
# 被装饰的函数 没有参数没有返回值
#     内部函数也没有参数 没有返回值
# 没有参数 有返回值
#        内部函数也没有参数 有返回值

#  被装饰的函数   有参数 有返回值
#           内部函数也有参数 有返回值

# import time
#
# def zhuangshiqi(func):
#     def neibuhanshu():
#         print("之前")
#         fdefanhuizhi = func()
#         print("之后")
#         return fdefanhuizhi
#     return neibuhanshu
#
#
# @zhuangshiqi
# def f():
#     time.sleep(3)
#     return "hello"
#
# i = f()
# print(i)
import time

# 装饰器
def zhuangshiqi(func):
    def nbhs(*args):
        t1=time.time()
        res=func(*args)
        t2=time.time()
        return res
    return nbhs

@zhuangshiqi
def add(*args):
    he = 0
    for i in args:
        he+=i
        time.sleep(0.01)
    return he

res = add(2,4,5)
print(res)
# TODO 装饰器规律：被装饰的函数【有参数】，内部函数就【有参数】；
#  被装饰的函数【有返回值】，内部函数就【有返回值】；
#  反之亦然。






# 装饰器规律：被装饰的函数有参数，内部函数就有参数；被装饰的函数有返回值，内部函数就有返回值；反之亦然。






